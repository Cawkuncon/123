from django.core.signing import JSONSerializer as BaseJSONSerializer

JSONSerializer = BaseJSONSerializer
